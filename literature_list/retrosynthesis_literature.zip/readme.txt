The 'nature2597.pdf' is the article referenced in the project proposal. Although it is no longer state of the art, still an interesting read. 

'AlphaGoNaturePaper.pdf' is the orginal paper by Deepmind on which the concepts in 'nature2597.pdf' are inspired. This paper is usefull for background info on monte carlo tree search (MCTS)

'seq2seq.pdf' is the first paper that approaches retrosynthesis as a seq2seq problem. This paper is often cited. 

'Karpov2019.pdf' is a paper the approaches the retrosynthesis task as a sequence to sequence (seq2seq) problem, similair to machine translation. It's results are not state of the art anymore, but servers as foundation for much followup work. 

'Augmented_Transformer.pdf' applies data augmentation to the models described in 'Karpov2019.pdf'.

'conditional_graph.pdf' treats retrosynthesis as a graph based problem, which is a very different approach than the seq2seq approach. This is definetly not the first work to do that but the conditional graph logic network is an interesting idea.

'graph_template_free.pdf' is the current state of the art on this specific benchmark task. It ourperfoms the seq2seq models by quite a large margin. 

'scm.pdf' is the publication by the Korean parter of SCM. 
